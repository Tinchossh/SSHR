"""
init.py
"""
from horilla import haystack_configuration
from horilla import horilla_apps
from horilla import horilla_middlewares
from horilla import horilla_context_processors
