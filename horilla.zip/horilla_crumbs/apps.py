from django.apps import AppConfig


class HorillaCrumbsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'horilla_crumbs'
