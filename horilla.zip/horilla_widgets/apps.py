from django.apps import AppConfig


class HorillaWidgetsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'horilla_widgets'
