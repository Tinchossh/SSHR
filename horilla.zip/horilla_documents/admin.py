from django.contrib import admin

from horilla_documents.models import Document, DocumentRequest


# Register your models here.
admin.site.register(Document)
admin.site.register(DocumentRequest)